# Lua Float — black floating Lua controller

Features in this project version:
- Black/dark interface.
- Draggable full floating controller with Run, Pause, Stop, Collapse and Close.
- Collapsed movable mini bubble; tap it to restore the panel.
- Multiple Lua files stored in `filesDir/scripts`.
- Error log saved to `filesDir/errors.log` and viewable from the main screen.
- Optional auto-run of the last saved/selected Lua script when a chosen Android package becomes foreground (requires Accessibility service and overlay permission).

## Build
Open this folder in Android Studio (current stable), allow Gradle sync, then Build > Build APK(s). The output is normally `app/build/outputs/apk/debug/app-debug.apk`.

## Setup
1. Install and open Lua Float.
2. Grant "Display over other apps".
3. Open Accessibility settings and enable Lua Float.
4. Enter the target app's Android package name, then save it.
5. Add/select a Lua script, save it, and show the floating panel.

## Lua API
`log("message")`, `wait(milliseconds)`, `tap(x,y)`, `swipe(x1,y1,x2,y2,durationMs)`.

## Important limitations
This is a source project, not a prebuilt APK. Auto-run executes the last saved/selected script when the selected package becomes foreground. Turn this off by clearing the target package field. Android/OEM background execution policies may affect behavior. Some apps block overlays/accessibility gestures. The app cannot guarantee operation in every app. Test only with apps and actions you are authorized to automate.
LuaJ's standard globals are powerful; do not run untrusted Lua files. For a public release, sandbox the Lua environment and restrict libraries/API access.
