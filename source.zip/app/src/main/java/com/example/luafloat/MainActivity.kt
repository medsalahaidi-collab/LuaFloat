package com.example.luafloat

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private lateinit var editor: EditText
    private lateinit var status: TextView
    private lateinit var scripts: Spinner
    private lateinit var packageInput: EditText
    private val names = mutableListOf<String>()
    private var selected = "main"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        refreshNames()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 24, 18, 18)
            setBackgroundColor(0xFF101010.toInt())
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text=text; textSize=size; setTextColor(0xFFF4F4F4.toInt()); setPadding(0,8,0,8)
        }
        root.addView(label("LUA FLOAT", 26f))
        status = label("محرر سكربتات Lua المتعددة", 13f).also { it.setTextColor(0xFFBDBDBD.toInt()) }

        scripts = Spinner(this)
        root.addView(label("السكربت"))
        root.addView(scripts)
        scripts.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                if (position in names.indices) { saveCurrent(); selected=names[position]; editor.setText(readScript(selected)) }
            }
        }
        val scriptButtons = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        scriptButtons.addView(button("جديد") {
            val name = "script${names.size+1}"
            if (!names.contains(name)) { saveCurrent(); names.add(name); selected=name; writeScript(name, "-- اكتب سكربتك هنا\\n"); refreshSpinner(); editor.setText(readScript(name)) }
        }, LinearLayout.LayoutParams(0,-2,1f))
        scriptButtons.addView(button("حفظ") { saveCurrent(); status.text="تم حفظ $selected" }, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(scriptButtons)

        editor = EditText(this).apply {
            setText(readScript(selected)); gravity=Gravity.TOP or Gravity.START
            textSize=13f; typeface=android.graphics.Typeface.MONOSPACE
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFFAAAAAA.toInt())
            setHint("-- Lua code"); setPadding(12,12,12,12); setBackgroundColor(0xFF252525.toInt()); minLines=9
        }
        root.addView(editor, LinearLayout.LayoutParams(-1,0,1f))
        root.addView(button("إظهار / تشغيل النافذة العائمة") {
            saveCurrent()
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                status.text="امنح إذن الظهور فوق التطبيقات ثم أعد الضغط"
            } else { startService(Intent(this,FloatingService::class.java)); status.text="النافذة العائمة جاهزة" }
        })
        root.addView(button("سجل الأخطاء") {
            val log=File(filesDir,"errors.log").let { if(it.exists()) it.readText() else "لا توجد أخطاء مسجلة." }
            AlertDialogBuilder.show(this,"سجل الأخطاء",log)
        })
        root.addView(label("التشغيل التلقائي عند فتح تطبيق (Package name)", 13f))
        packageInput=EditText(this).apply {
            setSingleLine(true); hint="مثال: com.example.app"
            setText(getSharedPreferences("luafloat_auto",0).getString("auto_package","") ?: "")
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFFAAAAAA.toInt())
        }
        root.addView(packageInput)
        root.addView(button("حفظ التطبيق المحدد للتشغيل التلقائي") {
            getSharedPreferences("luafloat_auto",0).edit().putString("auto_package",packageInput.text.toString().trim()).apply()
            status.text="تم حفظ اسم الحزمة. فعّل خدمة إمكانية الوصول أدناه."
        })
        root.addView(button("تفعيل إمكانية الوصول للنقر والتشغيل التلقائي") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        setContentView(root)
        refreshSpinner()
    }

    private fun button(text:String, action:()->Unit)=Button(this).apply { this.text=text; setOnClickListener { action() } }
    private fun scriptDir()=File(filesDir,"scripts").apply { mkdirs() }
    private fun scriptFile(name:String)=File(scriptDir(),name+".lua")
    private fun readScript(name:String)=scriptFile(name).let { if(it.exists()) it.readText() else "-- Lua script: $name\\n" }
    private fun writeScript(name:String, content:String)=scriptFile(name).writeText(content)
    private fun saveCurrent() {
        if (::editor.isInitialized) {
            writeScript(selected,editor.text.toString())
            getSharedPreferences("luafloat_auto",0).edit().putString("auto_script",selected).apply()
        }
    }
    private fun refreshNames() {
        names.clear(); names.addAll(scriptDir().listFiles()?.filter { it.extension=="lua" }?.map { it.nameWithoutExtension }?.sorted() ?: emptyList())
        if(names.isEmpty()) { names.add("main"); writeScript("main","-- Lua Float\\nlog('Hello')\\n") }
        if(!names.contains(selected)) selected=names.first()
    }
    private fun refreshSpinner() {
        refreshNames()
        scripts.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,names)
        val index=names.indexOf(selected); if(index>=0) scripts.setSelection(index)
    }
    override fun onPause() { super.onPause(); if(::editor.isInitialized) saveCurrent() }
}
