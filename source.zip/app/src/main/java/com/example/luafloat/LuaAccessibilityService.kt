package com.example.luafloat

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class LuaAccessibilityService : AccessibilityService() {
    private var lastLaunch=0L
    override fun onServiceConnected(){instance=this}
    override fun onAccessibilityEvent(event:AccessibilityEvent?) {
        if(event?.eventType!=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val wanted=getSharedPreferences("luafloat_auto",MODE_PRIVATE).getString("auto_package","") ?: return
        if(wanted.isNotBlank() && event.packageName?.toString()==wanted && System.currentTimeMillis()-lastLaunch>5000) {
            lastLaunch=System.currentTimeMillis()
            if(android.provider.Settings.canDrawOverlays(this)) startService(Intent(this,FloatingService::class.java).setAction("com.example.luafloat.AUTO_RUN"))
        }
    }
    override fun onInterrupt(){}
    override fun onDestroy(){if(instance===this)instance=null;super.onDestroy()}
    fun tapAt(x:Float,y:Float){val path=Path().apply{moveTo(x,y)};val g=GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,80)).build();dispatchGesture(g,null,null)}
    fun swipe(x1:Float,y1:Float,x2:Float,y2:Float,duration:Long){val path=Path().apply{moveTo(x1,y1);lineTo(x2,y2)};val g=GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,duration.coerceIn(80,5000))).build();dispatchGesture(g,null,null)}
    companion object{@Volatile var instance:LuaAccessibilityService?=null}
}
