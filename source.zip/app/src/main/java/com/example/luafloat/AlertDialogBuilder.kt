package com.example.luafloat
import android.app.AlertDialog
import android.content.Context
import android.text.method.ScrollingMovementMethod
import android.widget.TextView
object AlertDialogBuilder {
    fun show(context: Context, title: String, message: String) {
        val view=TextView(context).apply { text=message; setPadding(28,20,28,20); movementMethod=ScrollingMovementMethod() }
        AlertDialog.Builder(context).setTitle(title).setView(view).setPositiveButton("إغلاق",null).show()
    }
}
