package com.example.luafloat

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import android.graphics.Color
import org.luaj.vm2.Globals
import org.luaj.vm2.lib.jse.JsePlatform
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams
    private val running=AtomicBoolean(false)
    @Volatile private var paused=false
    @Volatile private var worker:Thread?=null
    private var compact=false
    private var selectedScript="main"

    override fun onCreate() { super.onCreate(); startForeground(7,notification()); wm=getSystemService(WINDOW_SERVICE) as WindowManager; showPanel() }
    private fun notification():Notification {
        val channel="luafloat"
        if(Build.VERSION.SDK_INT>=26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(channel,"Lua Float",NotificationManager.IMPORTANCE_LOW))
        return if(Build.VERSION.SDK_INT>=26) Notification.Builder(this,channel).setContentTitle("Lua Float").setContentText("التحكم العائم جاهز").setSmallIcon(android.R.drawable.ic_media_play).build()
        else Notification.Builder(this).setContentTitle("Lua Float").setSmallIcon(android.R.drawable.ic_media_play).build()
    }
    private fun button(label:String, action:()->Unit)=Button(this).apply {
        text=label; textSize=14f; minWidth=42; setTextColor(Color.WHITE); setBackgroundColor(0xFF333333.toInt()); setPadding(2,0,2,0); setOnClickListener { action() }
    }
    private fun showPanel() {
        if(panel!=null) return
        val outer=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(9,7,9,7); setBackgroundColor(0xF0101010.toInt()) }
        val header=TextView(this).apply { text="⠿  LUA FLOAT  •  اسحب للتحريك"; textSize=12f; setTextColor(Color.WHITE); setPadding(8,6,8,8) }
        val controls=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        controls.addView(button("▶"){runLua()}); controls.addView(button("Ⅱ"){paused=!paused})
        controls.addView(button("■"){stopLua()}); controls.addView(button("—"){collapse()})
        controls.addView(button("×"){stopSelf()})
        val choose=Spinner(this)
        val scripts=scriptFiles()
        choose.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,scripts.map{it.nameWithoutExtension})
        choose.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent:android.widget.AdapterView<*>?){}
            override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long){ if(position in scripts.indices) selectedScript=scripts[position].nameWithoutExtension }
        }
        outer.addView(header); outer.addView(choose); outer.addView(controls)
        val type=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        params=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT)
        params.gravity=Gravity.TOP or Gravity.START; params.x=28; params.y=180
        header.setOnTouchListener(object:View.OnTouchListener{
            var sx=0f;var sy=0f;var ox=0;var oy=0
            override fun onTouch(v:View,e:MotionEvent):Boolean { when(e.action){
                MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;ox=params.x;oy=params.y;return true}
                MotionEvent.ACTION_MOVE->{params.x=ox+(e.rawX-sx).toInt();params.y=oy+(e.rawY-sy).toInt();wm.updateViewLayout(outer,params);return true}
            };return true}
        })
        wm.addView(outer,params);panel=outer
    }
    private fun collapse() {
        panel?.let { try{wm.removeView(it)}catch(_:Exception){} }; panel=null
        val bubble=TextView(this).apply { text="Lua"; textSize=14f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; setPadding(15,12,15,12); setBackgroundColor(0xFF222222.toInt()); setOnClickListener { try{wm.removeView(this)}catch(_:Exception){}; panel=null; showPanel() } }
        val type=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        params=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT)
        params.gravity=Gravity.TOP or Gravity.START; params.x=25;params.y=200;wm.addView(bubble,params);panel=bubble
        bubble.setOnTouchListener(object:View.OnTouchListener{
            var sx=0f;var sy=0f;var ox=0;var oy=0
            override fun onTouch(v:View,e:MotionEvent):Boolean{when(e.action){
                MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;ox=params.x;oy=params.y;return true}
                MotionEvent.ACTION_MOVE->{params.x=ox+(e.rawX-sx).toInt();params.y=oy+(e.rawY-sy).toInt();wm.updateViewLayout(bubble,params);return true}
            };return false}
        })
    }
    private fun scriptFiles()=File(filesDir,"scripts").listFiles()?.filter{it.extension=="lua"}?.sortedBy{it.name} ?: emptyList()
    private fun logError(message:String) { synchronized(this) { File(filesDir,"errors.log").appendText("${System.currentTimeMillis()}: $message\\n") } }
    private fun runLua() {
        if(!running.compareAndSet(false,true)) return
        val file=File(File(filesDir,"scripts"),"$selectedScript.lua")
        if(!file.exists()){running.set(false);return}
        paused=false
        worker=thread(name="LuaFloatWorker") {
            try {
                val globals:Globals=JsePlatform.standardGlobals()
                globals.set("log",object:org.luaj.vm2.lib.OneArgFunction(){override fun call(arg:org.luaj.vm2.LuaValue):org.luaj.vm2.LuaValue{android.util.Log.i("LuaFloat",arg.tojstring());return org.luaj.vm2.LuaValue.NIL}})
                globals.set("wait",object:org.luaj.vm2.lib.OneArgFunction(){override fun call(arg:org.luaj.vm2.LuaValue):org.luaj.vm2.LuaValue{var left=arg.tolong().coerceIn(0,600000);while(left>0&&running.get()){while(paused&&running.get())Thread.sleep(100);val n=minOf(left,100L);Thread.sleep(n);left-=n};return org.luaj.vm2.LuaValue.NIL}})
                globals.set("tap",object:org.luaj.vm2.lib.TwoArgFunction(){override fun call(x:org.luaj.vm2.LuaValue,y:org.luaj.vm2.LuaValue):org.luaj.vm2.LuaValue{while(paused&&running.get())Thread.sleep(100);if(running.get())LuaAccessibilityService.instance?.tapAt(x.tofloat(),y.tofloat());return org.luaj.vm2.LuaValue.NIL}})
                globals.set("swipe",object:org.luaj.vm2.lib.VarArgFunction(){override fun invoke(a:org.luaj.vm2.Varargs):org.luaj.vm2.Varargs{while(paused&&running.get())Thread.sleep(100);if(running.get())LuaAccessibilityService.instance?.swipe(a.arg(1).tofloat(),a.arg(2).tofloat(),a.arg(3).tofloat(),a.arg(4).tofloat(),a.arg(5).optlong(400));return org.luaj.vm2.LuaValue.NONE}})
                globals.load(file.readText(),"user-script").call()
            } catch(e:Exception){logError("$selectedScript: ${e.message}");android.util.Log.e("LuaFloat","Lua error",e)}
            finally{running.set(false);paused=false}
        }
    }
    private fun stopLua(){running.set(false);paused=false;worker?.interrupt();worker=null}
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
        if(intent?.action=="com.example.luafloat.AUTO_RUN") {
            selectedScript=getSharedPreferences("luafloat_auto",Context.MODE_PRIVATE).getString("auto_script","main") ?: "main"
            runLua()
        }
        return START_STICKY
    }
    override fun onDestroy(){stopLua();panel?.let{try{wm.removeView(it)}catch(_:Exception){}};panel=null;super.onDestroy()}
    override fun onBind(intent:Intent?):IBinder?=null
}
